import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Image;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class WinDiary extends JDialog {

	private final JPanel contentPanel = new JPanel();
	private JTextField txtmDate;
	private JTextField txtTitle;
	private JTextField txtWriter;
	private JTextField txtNumber;
	private JTextField txtPassword;
	JLabel lblPicture;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		try {
			WinDiary dialog = new WinDiary();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public WinDiary() {
		setTitle("Diary(***�� �ϱ���)");
		setBounds(100, 100, 548, 586);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		txtmDate = new JTextField();
		txtmDate.setBounds(76, 10, 116, 21);
		contentPanel.add(txtmDate);
		txtmDate.setColumns(10);
		
		JLabel lblDate = new JLabel("��¥:");
		lblDate.setBounds(7, 16, 57, 15);
		contentPanel.add(lblDate);
		
		JLabel lblTitle = new JLabel("����:");
		lblTitle.setBounds(7, 47, 57, 15);
		contentPanel.add(lblTitle);
		
		txtTitle = new JTextField();
		txtTitle.setColumns(10);
		txtTitle.setBounds(76, 41, 358, 21);
		contentPanel.add(txtTitle);
		
		JLabel lblWeather = new JLabel("����:");
		lblWeather.setBounds(7, 78, 57, 15);
		contentPanel.add(lblWeather);
		
		JComboBox cbWeather = new JComboBox();
		cbWeather.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//System.out.println(cbWeather.getSelectedItem());
				String strWeather = cbWeather.getSelectedItem().toString();
				ImageIcon icon = new ImageIcon("./images/" + strWeather + ".png");
				Image pic = icon.getImage();
				pic = pic.getScaledInstance(123, 121, Image.SCALE_SMOOTH);
				icon = new ImageIcon(pic);
				lblPicture.setIcon(icon);
			}
		});
		cbWeather.setModel(new DefaultComboBoxModel(new String[] {"����", "�帲", "����", "��", "��"}));
		cbWeather.setBounds(76, 72, 116, 23);
		contentPanel.add(cbWeather);
		
		JLabel lblWriter = new JLabel("�ۼ���:");
		lblWriter.setBounds(7, 109, 57, 15);
		contentPanel.add(lblWriter);
		
		txtWriter = new JTextField();
		txtWriter.setColumns(10);
		txtWriter.setBounds(76, 103, 116, 21);
		contentPanel.add(txtWriter);
		
		txtNumber = new JTextField();
		txtNumber.setColumns(10);
		txtNumber.setBounds(76, 136, 116, 21);
		contentPanel.add(txtNumber);
		
		JLabel lblNumber = new JLabel("��ȣ:");
		lblNumber.setBounds(7, 142, 57, 15);
		contentPanel.add(lblNumber);
		
		JLabel lblPassword = new JLabel("��й�ȣ:");
		lblPassword.setBounds(7, 173, 57, 15);
		contentPanel.add(lblPassword);
		
		txtPassword = new JTextField();
		txtPassword.setColumns(10);
		txtPassword.setBounds(76, 167, 116, 21);
		contentPanel.add(txtPassword);
		
		lblPicture = new JLabel("");
		lblPicture.setIcon(new ImageIcon("./images/����.png"));
		lblPicture.setBackground(Color.YELLOW);
		lblPicture.setBounds(227, 72, 123, 121);
		lblPicture.setOpaque(true);
		contentPanel.add(lblPicture);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(7, 198, 513, 339);
		contentPanel.add(scrollPane);
		
		JTextArea taContents = new JTextArea();
		taContents.setLineWrap(true);
		scrollPane.setViewportView(taContents);
		
		JButton btnAdd = new JButton("�ۼ��ϱ�");
		btnAdd.setBounds(423, 136, 97, 52);
		contentPanel.add(btnAdd);
	}
}
